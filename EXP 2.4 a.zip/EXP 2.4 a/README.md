Java Application
======================
This is a simple Java application. This application serves as a basic template for a console application using Java.

# How to run?
Open the terminal run run the following command to run the Java program 

```sh
java Main.java
```